# Vert.x + Yoke Gradle Template

Template project for creating a Vert.x + Yoke module with a Gradle build.

Clone this and adapt it to easily develop Vert.x modules using Gradle as your build tool.

See the [build script](build.gradle) for the list of useful tasks
